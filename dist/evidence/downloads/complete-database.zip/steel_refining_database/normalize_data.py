"""Derive SI values without assuming unreported gas reference states."""
from pathlib import Path
import sqlite3,csv
ROOT=Path(__file__).resolve().parent
# unit, SI unit, factor, offset, reference basis
UNITS=[('t','kg',1000,0,'mass'),('kg','kg',1,0,'mass'),('min','s',60,0,'time'),('s','s',1,0,'time'),
('degC','K',1,273.15,'absolute_temperature'),('K','K',1,0,'as_reported_temperature_or_difference'),
('m','m',1,0,'length'),('mm','m',0.001,0,'length'),('um','m',1e-6,0,'length'),
('wt%','kg/kg',0.01,0,'mass_fraction'),('ppm','kg/kg',1e-6,0,'mass_ppm_per_source'),
('ppm_oxygen_activity','ppm_oxygen_activity',1,0,'oxygen_activity_proxy_not_total_oxygen'),
('percentage_points','fraction_difference',0.01,0,'difference_not_relative_change'),
('percent','relative_fraction_or_percentage',0.01,0,'role_and_parameter_required'),
('Nm3/h','normal_m3/s',1/3600,0,'normal_state_as_source'),('NL/min','normal_m3/s',1/60000,0,'normal_state_as_source'),
('Nm3','normal_m3',1,0,'normal_state_as_source'),('Nm3/t','normal_m3/kg',0.001,0,'normal_state_as_source'),
('m3_unspecified','m3_unspecified',1,0,'reference_state_unknown'),('dm3/min_unspecified','m3/s_unspecified',1/60000,0,'reference_state_unknown'),
('L/min_unspecified','m3/s_unspecified',1/60000,0,'reference_state_unknown'),('m3/h_unspecified','m3/s_unspecified',1/3600,0,'reference_state_unknown'),
('m3_unspecified/t','m3_unspecified/kg',0.001,0,'reference_state_unknown'),('NL/(min*t)','normal_m3/(s*kg)',1/60000000,0,'normal_state_as_source'),
('t/min','kg/s',1000/60,0,'mass_flow'),('Pa_abs','Pa_abs',1,0,'absolute_pressure'),('1/min','1/s',1/60,0,'rate'),
('kg/s','kg/s',1,0,'mass_flow'),('kg/t','kg/kg_steel',0.001,0,'specific_addition'),('m2/s','m2/s',1,0,'diffusivity'),
('kg/m3','kg/m3',1,0,'density'),('J/(kg*K)','J/(kg*K)',1,0,'specific_heat'),('Pa*s','Pa*s',1,0,'dynamic_viscosity'),
('1','1',1,0,'dimensionless'),('CaO/SiO2','mass_ratio_CaO_SiO2',1,0,'binary_basicity'),('count','count',1,0,'count'),('kWh','J',3600000,0,'energy'),
('fraction_or_basis_unresolved','unresolved',1,0,'quarantined')]

def main():
    con=sqlite3.connect(ROOT/'data/refining.sqlite');con.row_factory=sqlite3.Row
    con.executescript('''DROP VIEW IF EXISTS normalized_evidence; DROP TABLE IF EXISTS normalized_observations; DROP TABLE IF EXISTS units;
    CREATE TABLE units(raw_unit TEXT PRIMARY KEY,si_unit TEXT,factor REAL,offset REAL,basis TEXT);
    CREATE TABLE normalized_observations(observation_id TEXT PRIMARY KEY REFERENCES observations,si_value REAL,si_lower REAL,si_upper REAL,si_unit TEXT,reference_basis TEXT,formula TEXT);
    CREATE VIEW normalized_evidence AS SELECT o.*,n.si_value,n.si_lower,n.si_upper,n.si_unit,n.reference_basis FROM evidence_chain o JOIN normalized_observations n USING(observation_id);
    CREATE TABLE IF NOT EXISTS model_sources(model_id TEXT REFERENCES models,source_id TEXT REFERENCES sources,PRIMARY KEY(model_id,source_id));
    CREATE TABLE IF NOT EXISTS route_steps(route_id TEXT REFERENCES routes,step_no INTEGER,equipment_id TEXT REFERENCES equipment,PRIMARY KEY(route_id,step_no));
    CREATE TABLE IF NOT EXISTS grade_case_links(grade_id TEXT REFERENCES grade_families,case_id TEXT REFERENCES cases,PRIMARY KEY(grade_id,case_id));
    CREATE TABLE IF NOT EXISTS model_observation_links(model_id TEXT REFERENCES models,input_parameter TEXT,observation_id TEXT REFERENCES observations,purpose TEXT,domain_warning TEXT,PRIMARY KEY(model_id,input_parameter,observation_id));
    ''')
    con.executemany('INSERT INTO units VALUES(?,?,?,?,?)',UNITS);mapping={r[0]:r for r in UNITS};out=[]
    for row in con.execute('SELECT * FROM observations'):
        if row['unit'] not in mapping:raise ValueError('Unmapped unit '+row['unit'])
        raw,si,factor,offset,basis=mapping[row['unit']]
        values=[row[x]*factor+offset if row[x] is not None else None for x in ('value','lower_value','upper_value')]
        record=dict(observation_id=row['observation_id'],si_value=values[0],si_lower=values[1],si_upper=values[2],si_unit=si,reference_basis=basis,formula=f'x*{factor}+{offset}')
        con.execute('INSERT INTO normalized_observations VALUES(?,?,?,?,?,?,?)',list(record.values()));out.append(record)
    con.commit()
    import json
    con.execute('DELETE FROM model_sources');con.execute('DELETE FROM route_steps');con.execute('DELETE FROM grade_case_links');con.execute('DELETE FROM model_observation_links')
    for row in con.execute('SELECT model_id,source_ids_json FROM models').fetchall():
        con.executemany('INSERT INTO model_sources VALUES(?,?)',[(row[0],s) for s in json.loads(row[1])])
    for row in con.execute('SELECT route_id,steps_json FROM routes').fetchall():
        con.executemany('INSERT INTO route_steps VALUES(?,?,?)',[(row[0],i+1,e) for i,e in enumerate(json.loads(row[1]))])
    for gid,where in [('STRUCT',"grade IN ('Q355B','S355')"),('HOTSTRIP',"grade='SPHC'"),('REBAR',"grade='HRB400'"),('IF',"grade IN ('IF','IF_ULC','ULC','low_carbon_ULC')")]:
        con.executemany('INSERT INTO grade_case_links VALUES(?,?)',[(gid,r[0]) for r in con.execute('SELECT case_id FROM cases WHERE '+where)])
    bindings=[('M03','D_m2_s','LES44','sulfur_diffusivity','source_input_candidate','Only sulfur at1873K; not every species or temperature'),('M18','cp','S355CFD','cp','adopted_property_candidate','680 is adopted for study; no automatic transfer to another steel'),('M07','wm0','CFDS2022','S_wt_pct','initial_condition_candidate','Convert wt% to fraction; not a calibrated process trajectory'),('M07','Lw','W210','partition_mass_fraction','negative_example_DO_NOT_USE','Thymol water/oil partition35 is NOT steel-slag sulfur Lw'),('M02','QN_m3_s','VD105','argon_flow','gas_input_candidate','NL state exact definition still must be checked; total two plugs'),('M12','q_kg_s','RHaltitude','circulation_modified','comparison_only','Numerical result for source immersion/altitude; not a q(Q) calibration')]
    for mid,param,cid,p,purpose,warn in bindings:
        oid=con.execute('SELECT observation_id FROM observations WHERE case_id=? AND parameter=?',(cid,p)).fetchone()[0]
        con.execute('INSERT INTO model_observation_links VALUES(?,?,?,?,?)',(mid,param,oid,purpose,warn))
    con.commit()
    for name,records in [('normalized_observations',out),('units',[dict(zip(['raw_unit','si_unit','factor','offset','basis'],r)) for r in UNITS])]:
        with (ROOT/'data'/f'{name}.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,records[0].keys());w.writeheader();w.writerows(records)
    for name in ['model_sources','route_steps','grade_case_links','model_observation_links']:
        cur=con.execute('SELECT * FROM '+name);records=cur.fetchall()
        with (ROOT/'data'/f'{name}.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f);w.writerow([d[0] for d in cur.description]);w.writerows(records)
    con.close();print(f'Normalized {len(out)} observations without inventing gas standard state.')
if __name__=='__main__':main()
