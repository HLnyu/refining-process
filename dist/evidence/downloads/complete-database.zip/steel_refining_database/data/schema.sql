CREATE TABLE sources(source_id TEXT PRIMARY KEY,title TEXT NOT NULL,publication_year INTEGER,doi TEXT UNIQUE,url TEXT NOT NULL,verified_on TEXT,access_level TEXT,scope TEXT,original_data_vintage TEXT,note TEXT,date_precision TEXT,publication_date TEXT,numeric_corpus INTEGER);

CREATE TABLE cases(case_id TEXT PRIMARY KEY,source_id TEXT NOT NULL REFERENCES sources,process TEXT,grade TEXT,study_kind TEXT,context_json TEXT NOT NULL);

CREATE TABLE observations(observation_id TEXT PRIMARY KEY,case_id TEXT NOT NULL REFERENCES cases,source_id TEXT NOT NULL REFERENCES sources,parameter TEXT NOT NULL,value REAL,lower_value REAL,upper_value REAL,unit TEXT NOT NULL,evidence_tag TEXT CHECK(evidence_tag IN ('R','D','A','F','U')),quantity_role TEXT,locator TEXT NOT NULL,extraction_method TEXT,note TEXT,review_status TEXT,uncertainty REAL,CHECK(value IS NOT NULL OR lower_value IS NOT NULL OR upper_value IS NOT NULL),CHECK(lower_value IS NULL OR upper_value IS NULL OR lower_value<=upper_value));

CREATE TABLE derivations(derived_observation_id TEXT PRIMARY KEY REFERENCES observations,parent_ids_json TEXT,formula TEXT);

CREATE TABLE models(model_id TEXT PRIMARY KEY,name TEXT,equation TEXT,inputs_json TEXT,output_units TEXT,source_ids_json TEXT,derivation TEXT,domain TEXT,status TEXT,implementation TEXT);

CREATE TABLE reactions(reaction_id TEXT PRIMARY KEY,name TEXT,equation TEXT,processes TEXT,source_ids_json TEXT,note TEXT);

CREATE TABLE equipment(equipment_id TEXT PRIMARY KEY,name TEXT,scope TEXT,functions TEXT,temperature_rule TEXT,time_rule TEXT,source_ids_json TEXT,status TEXT);

CREATE TABLE grade_families(grade_id TEXT PRIMARY KEY,name TEXT,examples TEXT,quality_drivers TEXT,coverage_status TEXT,note TEXT);

CREATE TABLE routes(route_id TEXT PRIMARY KEY,grade_id TEXT REFERENCES grade_families,steps_json TEXT,selection_rule TEXT,source_ids_json TEXT,status TEXT);

CREATE TABLE data_gaps(gap_id TEXT PRIMARY KEY,topic TEXT,severity TEXT,missing_data TEXT,impact TEXT,next_action TEXT);

CREATE TABLE source_assets(source_id TEXT REFERENCES sources,local_path TEXT,sha256 TEXT,kind TEXT);

CREATE TABLE heat_imports(plant_id TEXT,heat_id TEXT,equipment_id TEXT,event_time TEXT,event_type TEXT,value REAL,unit TEXT,parameter TEXT,quality_flag TEXT,source_file TEXT,PRIMARY KEY(plant_id,heat_id,event_time,event_type,parameter));

CREATE TABLE calibrations(calibration_id TEXT PRIMARY KEY,model_id TEXT REFERENCES models,plant_id TEXT,equipment_id TEXT,parameter_json TEXT,training_heat_ids_json TEXT,test_heat_ids_json TEXT,metrics_json TEXT,status TEXT);

CREATE TABLE predictions(run_id TEXT PRIMARY KEY,scenario_type TEXT,input_json TEXT,result_json TEXT,model_ids_json TEXT,source_ids_json TEXT,calibration_id TEXT REFERENCES calibrations,created_on TEXT);

CREATE VIEW evidence_chain AS SELECT o.*,c.process,c.grade,c.study_kind,c.context_json,s.title,s.publication_year,s.original_data_vintage,s.url,s.access_level FROM observations o JOIN cases c USING(case_id) JOIN sources s ON o.source_id=s.source_id;

CREATE VIEW contemporary_evidence AS SELECT * FROM evidence_chain WHERE publication_year BETWEEN 2017 AND 2026 AND quantity_role NOT IN ('historical_input','historical_range') AND evidence_tag<>'U';

CREATE VIEW usable_reference_evidence AS SELECT * FROM evidence_chain WHERE evidence_tag<>'U' AND quantity_role NOT IN ('historical_range','historical_input') AND review_status='checked_with_accessible_text';

CREATE INDEX observations_param ON observations(parameter);

CREATE INDEX cases_process ON cases(process);

CREATE TABLE units(raw_unit TEXT PRIMARY KEY,si_unit TEXT,factor REAL,offset REAL,basis TEXT);

CREATE TABLE normalized_observations(observation_id TEXT PRIMARY KEY REFERENCES observations,si_value REAL,si_lower REAL,si_upper REAL,si_unit TEXT,reference_basis TEXT,formula TEXT);

CREATE VIEW normalized_evidence AS SELECT o.*,n.si_value,n.si_lower,n.si_upper,n.si_unit,n.reference_basis FROM evidence_chain o JOIN normalized_observations n USING(observation_id);

CREATE TABLE model_sources(model_id TEXT REFERENCES models,source_id TEXT REFERENCES sources,PRIMARY KEY(model_id,source_id));

CREATE TABLE route_steps(route_id TEXT REFERENCES routes,step_no INTEGER,equipment_id TEXT REFERENCES equipment,PRIMARY KEY(route_id,step_no));

CREATE TABLE grade_case_links(grade_id TEXT REFERENCES grade_families,case_id TEXT REFERENCES cases,PRIMARY KEY(grade_id,case_id));

CREATE TABLE model_observation_links(model_id TEXT REFERENCES models,input_parameter TEXT,observation_id TEXT REFERENCES observations,purpose TEXT,domain_warning TEXT,PRIMARY KEY(model_id,input_parameter,observation_id));
