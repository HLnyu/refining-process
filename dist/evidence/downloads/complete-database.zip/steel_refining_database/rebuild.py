"""One-command reproducible rebuild, audit and meaningful numerical tests."""
import json,subprocess,sys,os,zipfile
from pathlib import Path
import build_database,normalize_data,make_deliverables
ROOT=Path(__file__).resolve().parent

def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    build_database.build();normalize_data.main();make_deliverables.main()
    env={**os.environ,'PYTHONIOENCODING':'utf-8'}
    result=subprocess.run([sys.executable,'-m','unittest','-v','test_models.py'],cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8')
    (ROOT/'reports/tests.txt').write_text(result.stdout+result.stderr,encoding='utf-8')
    if result.returncode:
        print(result.stderr);raise SystemExit(result.returncode)
    scenario=subprocess.run([sys.executable,'cli.py','predict','examples/lf_synthetic.json'],cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8')
    if scenario.returncode:
        print(scenario.stderr);raise SystemExit(scenario.returncode)
    (ROOT/'reports/last_scenario.json').write_text(json.dumps(json.loads(scenario.stdout),ensure_ascii=False,indent=2),encoding='utf-8')
    archive=ROOT.parent/'普钢精炼数据库_v0.1_20261026.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for path in ROOT.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:
                z.write(path,Path(ROOT.name)/path.relative_to(ROOT))
    print('Rebuild, audit, tests and synthetic integration scenario passed.')
    print(str(archive))
if __name__=='__main__':main()
