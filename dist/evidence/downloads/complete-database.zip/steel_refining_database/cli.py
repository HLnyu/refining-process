import argparse, json, sqlite3, sys
from pathlib import Path
import models
from scenario import simulate_lf
ROOT=Path(__file__).resolve().parent

def db():
    c=sqlite3.connect(ROOT/'data/refining.sqlite');c.row_factory=sqlite3.Row;return c

def stats():
    c=db();names=['sources','cases','observations','models','reactions','equipment','grade_families','routes','data_gaps','heat_imports','calibrations']
    out={n:c.execute(f'SELECT count(*) FROM {n}').fetchone()[0] for n in names}
    out['matched_industrial_heats']=c.execute("SELECT count(*) FROM cases WHERE study_kind='industrial_heat'").fetchone()[0]
    out['source_years']=[dict(r) for r in c.execute('SELECT publication_year,count(*) AS n FROM sources GROUP BY publication_year')]
    out['model_status']=[dict(r) for r in c.execute('SELECT status,count(*) AS n FROM models GROUP BY status')]
    c.close();return out

def search(q):
    c=db();like=f'%{q}%';result={}
    for table,fields in [('sources',['title','scope','note']),('cases',['grade','process','context_json']),('models',['name','equation','domain']),('grade_families',['name','examples'])]:
        result[table]=[dict(r) for r in c.execute(f'SELECT * FROM {table} WHERE '+ ' OR '.join(f'{f} LIKE ?' for f in fields),[like]*len(fields))]
    c.close();return result

def audit():
    c=db();issues=[]
    for r in c.execute('PRAGMA foreign_key_check'):issues.append({'critical':'foreign key','row':list(r)})
    for r in c.execute('SELECT observation_id FROM observations o WHERE source_id != (SELECT source_id FROM cases WHERE case_id=o.case_id)'):issues.append({'critical':'case/source mismatch','id':r[0]})
    for r in c.execute("SELECT observation_id,unit FROM observations WHERE unit LIKE '%unspecified%'"):issues.append({'high':'gas volume reference unresolved','id':r[0],'unit':r[1]})
    for r in c.execute("SELECT source_id,note FROM sources WHERE note LIKE '%pending%' OR title LIKE '%pending%'"):issues.append({'high':'bibliography/date pending','source_id':r[0],'note':r[1]})
    for r in c.execute('SELECT derived_observation_id,parent_ids_json FROM derivations'):
        for parent in json.loads(r[1]):
            if not c.execute('SELECT 1 FROM observations WHERE observation_id=?',(parent,)).fetchone():issues.append({'critical':'missing derivation parent','id':r[0]})
    c.close();return {'checks':'referential integrity, source-case agreement, derivation parents, units, bibliography','issues':issues,'industrial_calibration':'absent; no accuracy claim'}

def demo():
    return {'scenario_type':'synthetic_scenario','not_a_plant_recipe':True,
        'Al_balance':models.aluminum_dose(100000,400,5,0,300,20,0.99),
        'sulfur':models.sulfur_two_phase(100000,1500,0.0002,0.001,100,0.001,600),
        'RH':models.rh_two_tank(90000,10000,1500,0.01,0,200,200,600,oxygen_available_ppm=500),
        'note':'All rates, closures and scenario values are illustrative assumptions, not calibrated predictions.'}

def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    p=argparse.ArgumentParser();p.add_argument('action',choices=['stats','search','audit','demo','predict']);p.add_argument('argument',nargs='?',default='');a=p.parse_args()
    if a.action=='predict':
        cfg=json.loads(Path(a.argument).read_text(encoding='utf-8'));result=simulate_lf(cfg)
        out=ROOT/'reports/last_scenario.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        result['saved_to']=str(out)
    elif a.action=='search':result=search(a.argument)
    else:result=globals()[a.action]()
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
