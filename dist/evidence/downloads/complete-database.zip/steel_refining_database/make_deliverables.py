"""Generate documentation, evidence catalogue, import templates and audit from DB."""
from pathlib import Path
import csv, json, sqlite3, hashlib
from cli import stats, audit
from registry import MODELS,EQUIPMENT,GRADES,ROUTES,GAPS

ROOT=Path(__file__).resolve().parent

def write(path,text):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')

def main():
    con=sqlite3.connect(ROOT/'data/refining.sqlite');con.row_factory=sqlite3.Row
    sources=[dict(r) for r in con.execute('SELECT * FROM sources')]
    source_map={r['source_id']:r for r in sources}
    def cites(ids):return ', '.join(f"[{i}]({source_map[i]['url']})" for i in json.loads(ids)) or '守恒/几何推导，非文献拟合参数'
    overview='''# 数据库结构、工序串联和覆盖边界

版本2026-10-26。数据库的“参数记录”不是独立炉次数；范围是一条记录，不把上下限拆成两个样本。研究输入、CFD输出、作者推荐、工业测量、企业目标与换算值分别保存。

## 核心连接

`sources → cases → observations → derivations` 保留每个数字的来源和工况。

`grade_families → routes → equipment` 给出产品族与设备路径。routes.steps_json中的设备ID对应equipment。

`models → source_ids_json / implementation` 将公式连接到原文和Python函数。

`heat_imports → calibrations → predictions` 是未来厂级数据与预测链；本版heat_imports和calibrations为空，不伪造训练数据。predictions表结构已准备，演示不自动作为工业预测入库。

同一工况关联case_id，而不是凭相同钢种把不同厂、不同炉、不同时间的数据合并。逐事件输入应携带plant_id、heat_id、equipment_id和时间戳。

## 时间和温度

加热、吹氩、加料可并行：阶段总时间是事件区间并集，不是全部持续时间之和。抽真空、深真空保压、破空、软吹和设备占用时间分开。每步都需要进站温度、随时间的热量和离站状态；上游目标按液相线、过热度及后续运输/等待逆算。

已有文献统计范围见S11的各case；不能将其最小值和最大值当作所有钢厂设计上下限。设备表里的温度/时间规则是模型入口；没有实测支持的工序没有强填分钟数。

## 数据字段说明

sources: source_id, title, DOI, URL, publication_year（卷期年）, publication_date（首次公开日期，缺失可空）, date_precision, 原始数据年代, 访问层级及核验日期。

cases: 同源同工况；study_kind指industrial_heat/industrial_aggregate/numerical_model/water_model等；context_json保存吨位、气体口径、砖布置、研究条件。案例ID不是工厂原始炉号。

observations: 参数名、点值或上下界、原始单位、R/D/A/F/U、数量角色、原表/页/节、核验状态、注释。quantity_role必须区分target、measured、difference、parameter_scan等。U及quarantined数据不用于参考计算。

derivations: 每个D值指向所有父观测及计算式，禁止跨case不解释地拼接。

所有未知数留空或待核，不以零替代。原文“-”未报告的合金量不插入零值。wt%除以100成为质量分数；ppm乘1e-6；吨乘1000成为kg；NL和Nm³以原文N状态为前提。L/min和dm³/min无N不得强改为标况。Pa_abs为绝压。

## 可直接使用的SQL

```sql
SELECT case_id,parameter,value,lower_value,upper_value,unit,locator,url
FROM evidence_chain WHERE grade='Q355B';

SELECT case_id,parameter,value,unit FROM evidence_chain
WHERE source_id='S05' AND study_kind='industrial_heat';

SELECT * FROM usable_reference_evidence WHERE process='RH';

SELECT * FROM models WHERE name LIKE '%传质%';
```

usable_reference_evidence仅排除了显式未核/历史复用项，不代表自动适配任何钢厂；仍必须核对工况、原始数据年代、标准状态、研究类型和模型适用域。

## 产品族覆盖

| ID | 产品族 | 代表牌号 | 本版覆盖 |
|---|---|---|---|
'''
    overview+='\n'.join(f"|{g['grade_id']}|{g['name']}|{g['examples']}|{g['coverage_status']}|" for g in GRADES)
    overview+='\n\n## 工序设备\n\n|ID|设备|范围|温度处理|时间处理|依据|\n|---|---|---|---|---|---|\n'
    overview+='\n'.join(f"|{e['equipment_id']}|{e['name']}|{e['scope']}|{e['temperature_rule']}|{e['time_rule']}|{cites(e['source_ids_json'])}|" for e in EQUIPMENT)
    overview+='\n\n## 路线串联\n\n'
    for r in ROUTES:overview+=f"- {r['route_id']} / {r['grade_id']}: {' → '.join(json.loads(r['steps_json']))}。{r['selection_rule']}。状态：{r['status']}。\n"
    overview+='''
## 后续规模化采集

1. 每个产品族先确定钢厂、设备和订单版本；采起点—操作时序—中间点—终点—铸坯实绩，不能只收最终合格炉次。
2. 原文图形数字化记录工具、坐标校准、读图误差，禁止标作原表实测。数值模拟案例记录原型/水模、几何相似比与流量换算。
3. 文献DOI去重不等于原始数据去重；文献引用同一历史数据集应保存dataset_group，避免训练验证重复。
4. 以钢厂/设备/钢种/吨位/流态建域，再做分层回归与带量纲检查的关联式；不把不同单位经验系数混合。
5. 若更改模型结构、数据或参数，保存模型版本、校准炉次及独立验证时间窗。不能用随机切分同炉时间点宣称独立验证。

## 尚未实现的全平台功能

本版不是自动工厂排程、全元素热力学引擎或最终产品性能认证。多合金优化、完整Al-O-渣-夹杂人口平衡、N去除/吸收、界面面积代理训练、多设备排队和下游性能模型已登记需求，但没有冒充实现。温度规则和设备目录也不是已经数字化的运行规程。
'''
    write('docs/数据库与串联说明.md',overview)

    formula='''# 动力学、配料与温度模型：公式与推导

所有实现均为研究内核，未获得本厂工业预测误差。标准库函数可执行并接受明确输入，缺少标定量时必须停算对应项。

## 必须分清的量

- k：m/s；A：m²；G=sum(k_j*A_j)：m³/s；gamma=G/V：1/s。不要把m³/s的kA写成1/s的kLa。
- Lw=ws/wm是质量分数分配比；h=Cs/Cm=Lw*rho_s/rho_m是质量浓度分配比。
- QN是给定N状态气量，Q_actual是浴温/绝压下气量；两者不是同一个自变量。
- RH循环量q为kg/s；t/min乘1000/60换算。钢包内流场局部循环通量不是RH上/下浸渍管之间的净交换量。
- 95%混匀时间是示踪浓度容差定义，不等于脱硫95%完成，也不等于加料耗时。

## 参数可识别性

若C(t)=Ceq+(C0-Ceq)exp(-gamma*t)，浓度序列只能识别gamma。对任何正数b，把k变为b*k、A变为A/b，都给相同gamma，不能唯一反推出两者。仅有一个终点且Ceq也未知时，连gamma都不能唯一确定。

分离k与A需要独立的面积测量/VOF、局部耗散与传质测量、不同激励下的多时间点，以及带物理边界的联合标定。RH的q与kv也存在类似补偿性，优先用示踪实验识别q，再估计反应参数。

## 串联方式

LF条件化计算：QN、绝压、浴深 → 气体膨胀功 → 输入局部耗散分配参数 → k_m → 双膜K → 输入VOF/测量/标定面积 → gamma → 有限渣量脱硫 → 下一阶段钢渣状态。

其中“局部耗散分配参数”和“面积”是待标定输入，不能声称此链已从气量独立预测所有隐变量。simulate_lf实现此分段串联并同步做热平衡；没有完全求解钢-渣-氧-夹杂多反应体系。

RH条件化计算：气量/压力/几何 → 经验证的气含率/回路阻力或示踪反算q → 双容器交换与反应 → 脱碳/脱氢时序；尾气碳收支提供独立核验。仅有气量时拒绝给可信q的无条件结果。

## 逐模型注册表
'''
    for md in MODELS:
        formula+=f"\n### {md['model_id']} {md['name']}\n\n- 状态：{md['status']}；实现：`{md['implementation']}`。\n- 方程：`{md['equation']}`。\n- 输入：{', '.join(json.loads(md['inputs_json']))}。输出：{md['output_units']}。\n- 来源：{cites(md['source_ids_json'])}。\n- 推导：{md['derivation']}\n- 适用与限制：{md['domain']}\n"
    formula+='''
## 有限渣量脱硫的完整推导

令钢质量Mm、渣质量Ms、硫质量分数wm、ws，总硫I=Mm*wm+Ms*ws不变。

界面驱动力为wm-ws/Lw。钢侧V=Mm/rho_m，gamma=K*A/V。

dwm/dt=-gamma*(wm-ws/Lw)，dws/dt=Mm/Ms*gamma*(wm-ws/Lw)。

由ws=(I-Mm*wm)/Ms消元，得到dwm/dt=-gamma*(1+Mm/(Ms*Lw))*(wm-wm_eq)。

wm_eq=I/(Mm+Ms*Lw)。所以终点与渣量和初渣硫有关，不是无限趋近于零；初渣富硫时允许返硫。取对数得到目标时间，目标≤wm_eq时有限时间不可达。

两膜推导：J=rho_m*km*(wm_bulk-wm_i)=rho_s*ks*(ws_i-ws_bulk)，ws_i=Lw*wm_i。消去界面浓度得1/K=1/km+rho_m/(rho_s*ks*Lw)。

## RH双容器边界

钢包Ml、真空室Mv分别完全混合，交换质量流量q，两侧交换项相加为零。只在真空室设kv*(Cv-Cstar)表观反应。当kv=0时全系统元素守恒；q=0时钢包浓度不变。RK4自动细分到最大无量纲步长≤0.02，并有氧预算检查。该结构是简化反应器模型，不是完整VOF/气泡人口平衡CFD。

## 不确定性与验证

rate_sensitivity返回的是参数敏感性包络，不能称95%统计区间。统计区间需要独立验证残差并检查实际覆盖率。单元测试验证守恒、极限、反算、单位/输入域；没有工业校准时不报告MAE/RMSE等模型精度。
'''
    write('docs/动力学模型与推导.md',formula)

    catalogue='# 来源与原文定位目录\n\n原始来源按DOI/URL去重；作者年份完整书目仍有待补字段。年份趋势不得用未解决的日期记录。资料访问状态如实保留。\n\n'
    for s in sources:
        count=con.execute('SELECT count(*) FROM observations WHERE source_id=?',(s['source_id'],)).fetchone()[0]
        catalogue+=f"## {s['source_id']} {s['title']}\n\n- 卷期年：{s['publication_year']}；首次公开：{s['publication_date'] or '未核至具体日期'}；精度：{s['date_precision']}。\n- DOI：{s['doi'] or '未提供/未核'}；[原始来源]({s['url']})。\n- 访问：{s['access_level']}；原始数据年代：{s['original_data_vintage']}。\n- 提取记录：{count}；范围：{s['scope']}。\n- 备注：{s['note']}\n\n"
    write('docs/来源目录.md',catalogue)
    rows=[dict(r) for r in con.execute('SELECT * FROM evidence_chain')]
    with (ROOT/'data/参数证据总表.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['记录ID','来源ID','工况ID','工序','钢种','研究类型','参数','原值','下限','上限','原始单位','证据类型','数量性质','原文定位','核验状态','备注','出版卷期年','数据原始年代','原始来源链接'])
        for o in rows:w.writerow([o[k] for k in ['observation_id','source_id','case_id','process','grade','study_kind','parameter','value','lower_value','upper_value','unit','evidence_tag','quantity_role','locator','review_status','note','publication_year','original_data_vintage','url']])
    evid='# 逐项参数证据\n\n每行参数≠独立样本。U为隔离项；R不自动代表工业测量。\n\n|ID|工况|参数|原文值/范围|单位|性质|定位|来源|\n|---|---|---|---|---|---|---|---|\n'
    for o in rows:
        val=o['value'] if o['value'] is not None else f"{o['lower_value']}—{o['upper_value']}"
        evid+=f"|{o['observation_id']}|{o['case_id']}|{o['parameter']}|{val}|{o['unit']}|{o['evidence_tag']}/{o['quantity_role']}|{o['locator']}|[{o['source_id']}]({o['url']})|\n"
    write('docs/逐项参数证据.md',evid)

    st=stats();au=audit();issues=au['issues']
    extra=[]
    for s in sources:
        if s['publication_date'] is None or s['date_precision']!='day':extra.append({'source_id':s['source_id'],'issue':'first-publication date not resolved to day'})
    quarantined=[dict(r) for r in con.execute("SELECT observation_id,case_id,parameter,value,unit,note FROM observations WHERE evidence_tag='U'")]
    report='# 数据质量审计\n\n2026-10-26。审计不等于工业模型认证。\n\n## 实际数量\n\n'
    report+='\n'.join(f'- {k}：{v}' for k,v in st.items() if isinstance(v,int))
    report+=f"\n\n计数说明：独立匹配工业炉次仅{st['matched_industrial_heats']}炉（S05选取的同源子集）；文献中的2701/627等是作者报告的统计样本量，没有这些炉次的逐炉数据，绝不把其加进数据库炉次总数。元数据/厂级公告/设备商条目均不等于可训练的过程数据。\n"
    report+='\n## 机械检查\n\n- SQLite integrity_check：'+str(con.execute('PRAGMA integrity_check').fetchone()[0])+'。\n- 外键、case-source一致性、换算父ID：'+('通过' if not any('critical' in x for x in issues) else '存在严重错误')+'。\n'
    report+=f'- 未解决气体体积口径记录：{sum(x.get("high")=="gas volume reference unresolved" for x in issues)}。\n- U隔离记录：{len(quarantined)}。\n- 不能补造的原始采集年份及缺失范围见sources/context_json。\n'
    report+='\n## 隔离和高风险项\n\n'
    for q in quarantined:report+=f"- {q['observation_id']} / {q['case_id']}：{q['parameter']}={q['value']} {q['unit']}；{q['note']}\n"
    report+='''
- S05的气量是设备记录/平均量，论文讨论高读数可能与泄漏有关；不能当所有气体都进了钢液。1号炉超长等待保留，不能悄悄删除后声称全样本稳定。
- S04是水-油-空气和百里香酚体系。分配比23/35及扩散系数不是钢渣脱硫物性。
- S03的经验式某些单位和网页排版有歧义；没有采用可疑系数，优先采用有单位推导的方程。
- S09的2024建模论文含2005工业输入；S13部分介绍中的速率范围来自更早文献，分开标记。
- S11的通电/软吹可能与其他操作重叠；真空保压与整个工位周期不可相加混用。
- S10企业目标不是国家钢种标准；不能用这些目标认证SPHC产品。
- 数据库没有强制把“未报告”变成零，没有将不同研究组装成同一炉次。

## 尚需补足

'''
    report+='\n'.join(f"- {g['gap_id']} {g['topic']}：{g['missing_data']}。影响：{g['impact']}。下一步：{g['next_action']}。" for g in GAPS)
    write('reports/质量审计.md',report)
    write('reports/quality_audit.json',json.dumps({'stats':st,'checks':au,'date_issues':extra,'quarantined':quarantined},ensure_ascii=False,indent=2))
    write('data/schema.sql',';\n\n'.join(r[0] for r in con.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%'"))+';\n')
    write('templates/heat_events.csv','plant_id,heat_id,equipment_id,event_time,event_type,parameter,value,unit,quality_flag,source_file\n')
    write('templates/concentration_series.csv','plant_id,heat_id,equipment_id,case_id,time_s,parameter,value,unit,measurement_method,source_file\n')
    write('templates/materials.csv','material_id,batch_id,element,mass_fraction,purity,recovery,price_per_kg,source_reference\n')
    write('templates/calibration_contract.json',json.dumps({'status':'template_not_fitted','required':['plant_id','equipment_id','grade_family','geometry','gas_normal_state','operating_domain','parameter_units','source_ids','training_heat_ids','test_heat_ids','time_split','metrics','uncertainty_coverage'],'forbidden':['same-heat leakage','retrospective endpoint features used as online inputs','U records used in training']},ensure_ascii=False,indent=2))
    example={
        'scenario_type':'synthetic_scenario',
        'provenance':{'all_operating_values':'user_assumption: demonstration only; not a literature heat','D_steel':'S02 reports4.8e-9 at1873K; used here only as illustrative constant','cp':'S05 adopted680; transfer to this scenario not validated','closures':'Lw, area, ks, epsilon factor, heat loss are explicit assumptions'},
        'state':{'steel_mass_kg':100000,'slag_mass_kg':1500,'S_steel_fraction':0.0002,'S_slag_fraction':0.001,'T_degC':1600},
        'parameters':{'steel_density_kg_m3':7000,'slag_density_kg_m3':2800,'bath_depth_m':2.8,'normal_temperature_K':273.15,'normal_pressure_Pa':101325,'diffusivity_steel_m2_s':4.8e-9,'nu_steel_m2_s':0.006/7000,'cp_J_kg_K':680},
        'phases':[{'name':'illustrative LF stage','duration_s':600,'QN_m3_s':50/3600,'surface_pressure_Pa':101325,'interface_epsilon_factor':2,'eddy_C':0.4,'ks_m_s':0.0001,'Lw':100,'A_resolved_m2':8,'area_effectiveness':0.8,'drop_volume_m3':0.001,'drop_d32_m':0.002,'electric_power_W':1500000,'electrical_efficiency':0.5,'reaction_heat_W':0,'heat_loss_W':300000,'addition_heat_J':0}]}
    write('examples/lf_synthetic.json',json.dumps(example,ensure_ascii=False,indent=2))
    queries=[('sources','检索并核对2016-10-26至2026-10-26公开原文；未穷尽','web_primary','S01-S36'),('kinetics','ladle mass transfer interfacial area RH circulation','web_primary','S01-S04,S13-S15,S31,S34'),('grades','Q355B S355 SPHC IF HRB400 Q235B','web_primary_and_local_original_text','S05,S06,S10,S12,S32,S33'),('factory','Shougang official low-carbon steelmaking 2024','official_plant','S25'),('fallback','academic_search.py ladle mass transfer RH circulation','OpenAlex_script_failed','WinError10013'),('access','direct urllib public PMC','direct_network','sandbox network denied; escalated request got challenge HTML, not usable original text')]
    with (ROOT/'data/search_log.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['date','topic','query_or_scope','method','result']);w.writerows(( '2026-10-26',*q) for q in queries)
    write('docs/检索与纳排规则.md','''# 检索与纳排

时间窗2016-10-26—2026-10-26。以首次公开日期为准；仅核至年份的条目保留日期精度，不假造1月1日。publication_year保留卷期年，所以2024卷期不必是2024首次公开。

优先原始期刊论文、钢厂署名工业研究、钢厂官方公告；设备商只支持能力说明。综述用于发现线索，数值应回溯原始研究。原文不可访问时，保留摘要/索引层级，不标作完整全文复核。

专用学术MCP缺失；OpenAlex备用脚本网络权限失败，部分期刊429或超时。采用J-STAGE、期刊原站、PMC和现有原PDF文本作为当前路径。不宣称已完成跨库系统综述。

不纳入：2013年HRB400专利、窗口之前2016年专利，及与钢液精炼无关的Q235B焊接/腐蚀论文。不以近十年专利参数替代用户要求的论文/钢厂实测数据。HRB400异常摘要数字仅隔离保存。

旧理论可作为推导基础，不伪装为十年内新增实验。近年论文复用旧数据单列。尚未核验所有年份的完整覆盖，2016窗口尾段未获得本版合格样本。
''')
    write('docs/模型证据绑定示例.md','''# 模型输入如何关联证据

model_sources为模型文献外键表；route_steps为路线步骤外键表；grade_case_links为产品族工况表；model_observation_links为模型输入与观测的候选绑定。

**绑定不等于自动可用。**purpose为negative_example_DO_NOT_USE的记录专门展示不能迁移的参数。W210的质量分数分配比35属于水-油-百里香酚，不得传给钢渣脱硫Lw。

```sql
SELECT m.name,b.input_parameter,b.purpose,b.domain_warning,
       e.value,e.unit,e.case_id,e.locator,e.url
FROM model_observation_links b
JOIN models m USING(model_id)
JOIN evidence_chain e USING(observation_id);

SELECT g.name,r.route_id,rs.step_no,e.name AS equipment
FROM grade_families g JOIN routes r USING(grade_id)
JOIN route_steps rs USING(route_id)
JOIN equipment e USING(equipment_id)
ORDER BY g.grade_id,r.route_id,rs.step_no;
```

仅有来源的候选参数可以用于条件化研究计算；要产生生产推荐，必须先通过工况域、材料体系、时间口径、气体状态和校准版本检查。来源不匹配时不自动按相近数值填空。
''')
    con.close();print('Generated documentation, audit, schema and templates.')

if __name__=='__main__':main()
