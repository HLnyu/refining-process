param([string]$Action='stats',[string]$Argument='')
$taskPython='C:\Users\HL\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $taskPython)) { $taskPython='python' }
& $taskPython (Join-Path $PSScriptRoot 'cli.py') $Action $Argument
