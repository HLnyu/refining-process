# 普钢出钢后精炼证据数据库与动力学计算内核

版本：2026-10-26，v0.1。检索窗口：2016-10-26—2026-10-26（以首次公开发表日期为主；仅有年份的记录注明日期精度）。

这是实际可查询的 SQLite 数据库、CSV/JSON 导出、公式注册表及可运行的 Python 计算内核。它不是已经完成十年穷尽检索、所有钢种覆盖或工业验证的生产预测软件。首批证据为定向检索和原文表格核对；没有私有钢厂炉次数据。不得将独立文献工况拼接为一个真实炉次。

## 文件入口

- `data/refining.sqlite`：关系数据库；`data/*.csv`：Excel可直接打开的UTF-8 BOM导出。
- `data/seed.json`：可编辑的全部结构化原始记录（从build_database.py再生成）。
- `docs/数据库与串联说明.md`：范围、数据字典、流程联结与未覆盖项目。
- `docs/动力学模型与推导.md`：每个模型的公式、单位、来源、假设及验证状态。
- `reports/质量审计.md`：实际统计数量、日期/单位问题、缺失与可用性。
- `models.py`：标准库实现的计算函数；`test_models.py`：守恒、极限、反算和异常输入检查。
- `cli.py`：统计、检索和独立演示；`run_database.ps1`：使用本机已核验Python路径启动。

## 操作

```powershell
.\run_database.ps1 stats
.\run_database.ps1 search Q355
.\run_database.ps1 search 传质
.\run_database.ps1 demo
.\run_database.ps1 audit
```

通用Python：`python rebuild.py`一键重建数据库、单位换算、文档、审计和测试；`python cli.py stats`查询统计。

条件化LF算例：`python cli.py predict examples/lf_synthetic.json`。该文件所有自定工况明确标为演示；有真实数据后应另存为conditional_user_scenario并填写参数依据。`data/normalized_observations.csv`保存可逆单位换算，未知气体基准仍保留unknown。

演示中的自定输入全部标为 synthetic_scenario，不是文献实测炉次，不存入observations。公式能运行与模型已获得工业预测精度是两件事。

## 证据规则

1. `R` 原文数值；`D` 同一工况换算；`A` 原作者假设/数值计算输入；`F` 原作者拟合或推荐；`U` 待核验。另外记录industrial/model/water_model等研究类型，R不自动等于工业实测。
2. 文献出版年与原始工业数据年份独立。2024论文复用2005工业数据时不得称2024实测。
3. m³、dm³、Nm³严格区分；没有标准状态证据的量不改写为标况。压力统一绝压但保留原口径。
4. 每个数字关联source_id、case_id、原文表/节、提取方法。空值不是零；上下限、增减量、目标与测量分开。
5. 文献经验式仅对其设备、几何、气量、物性及流态范围有效。模型无足够输入时返回错误/待校准，不自动填万能默认参数。
6. 不提供国家标准成分的自动牌号认证。产品族只是索引，具体订单须导入有效版本标准及企业内控。

外部资料的链接见sources表。未复制整篇付费论文；仅保存必要事实、表格定位和短说明。原工作区PDF的校验路径与SHA256记录在source_assets中。
