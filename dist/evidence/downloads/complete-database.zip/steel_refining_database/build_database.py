"""Rebuild a traceable evidence database; all extraction is explicit and reviewable."""
from pathlib import Path
import csv, hashlib, json, sqlite3
from datetime import date

ROOT=Path(__file__).resolve().parent
TODAY='2026-10-26'
sources=[]; cases=[]; observations=[]; derivations=[]; gaps=[]

def source(sid,title,year,doi,url,access,scope,vintage='not_reported',note='',date_precision='year'):
    sources.append(dict(source_id=sid,title=title,publication_year=year,doi=doi,url=url,
        verified_on=TODAY,access_level=access,scope=scope,original_data_vintage=vintage,
        note=note,date_precision=date_precision,publication_date=None,
        numeric_corpus=1 if year and 2017<=year<=2026 else 0))

def case(cid,sid,process,grade,kind,context):
    cases.append(dict(case_id=cid,source_id=sid,process=process,grade=grade,
        study_kind=kind,context_json=json.dumps(context,ensure_ascii=False)))

def obs(cid,parameter,value,unit,locator,tag='R',role='reported',lo=None,hi=None,note=''):
    sid=next(c['source_id'] for c in cases if c['case_id']==cid)
    oid=f'O{len(observations)+1:04d}'
    observations.append(dict(observation_id=oid,case_id=cid,source_id=sid,
        parameter=parameter,value=value,lower_value=lo,upper_value=hi,unit=unit,
        evidence_tag=tag,quantity_role=role,locator=locator,extraction_method='manual_primary_source',
        note=note,review_status='checked_with_accessible_text',uncertainty=None))
    return oid

def derive(cid,param,val,unit,parents,formula,note=''):
    oid=obs(cid,param,val,unit,'derived: '+formula,'D','derived',note=note)
    derivations.append(dict(derived_observation_id=oid,parent_ids_json=json.dumps(parents),formula=formula))

source('S01','Modeling and Optimisation of Gas Stirred Ladle Systems',2017,'10.2355/isijinternational.ISIJINT-2015-701','https://www.jstage.jst.go.jp/article/isijinternational/57/2/57_ISIJINT-2015-701/_html/-char/en','full_text','LF mixing, industrial gas regimes and physical-model correlations',note='Historical antecedents of formulas predate publication; not a new industrial cohort for every table row.')
source('S02','Modeling of Slag Entrainment and Interfacial Mass Transfer in Gas Stirred Ladles',2017,'10.2355/isijinternational.ISIJINT-2016-589','https://www.jstage.jst.go.jp/article/isijinternational/57/11/57_ISIJINT-2016-589/_html/-char/en','full_text','Entrained drops, interface zones, penetration model',note='Numerical model of 44 t geometry; do not identify with actual 44 t industrial heats.')
source('S03','Desulphurization Kinetic Prediction into a Steel Ladle by Coupling Thermodynamic Correlations, Fluidynamics and Heat Transfer',2022,'10.2355/isijinternational.ISIJINT-2021-514','https://www.jstage.jst.go.jp/article/isijinternational/62/6/62_ISIJINT-2021-514/_html/-char/en','full_text','LF sulfur kinetics, CFD and thermal coupling',note='Some equation labels/units rendered inconsistently. Ambiguous empirical coefficients quarantined, not executed.')
source('S04','Multiphase Modeling of Steel-slag Mass Transfer through Distorted Interface in Bottom-stirred Ladle',2024,'10.2355/isijinternational.ISIJINT-2023-310','https://www.jstage.jst.go.jp/article/isijinternational/64/1/64_ISIJINT-2023-310/_html/-char/en','full_text_and_pdf_text','210 t prototype, 1:10 physical model, transient interface',note='First online 2023-12-06; issue 2024-01-15. Thymol/oil partition is not steel-slag sulfur partition.')
source('S05','Industrial Investigations of S355 Steel-Grade Homogenization in a 100-Tonne Ladle Furnace',2025,'10.3390/ma18010180','https://pmc.ncbi.nlm.nih.gov/articles/PMC11722051/','full_text','S355 industrial observations and CFD mixing',note='46 tabled heats in source; bounded subset extracted here. Gas reference state unspecified; CFD omits slag.')
source('S06','Q355B加Ti降Mn工艺开发',2022,'10.12677/meng.2022.91008','https://doi.org/10.12677/meng.2022.91008','local_pdf_text','Baowu Echeng BOF-LF-CC Q355B industrial optimization',note='Plant-specific recipe, not Q355B standard chemistry.')
source('S07','Efficiently Removing Hydrogen of H-Supersaturated Liquid Steel in the Vacuum Degasser with Various Gas Injection Modes',2023,'10.3390/met13071229','https://www.mdpi.com/2075-4701/13/7/1229','publisher_index_and_prior_fulltext_review','105 t VD hydrogen model',note='Modeled H-supersaturation; this is not a universal industrial H endpoint guarantee.')
source('S08','Powder transport behavior in RH degasser with powder injection through up snorkel: a transient numerical model',2023,'10.1007/s42243-023-00973-x','https://doi.org/10.1007/s42243-023-00973-x','local_pdf_text','120 t RH powder transport and water-model validation',note='No complete powder chemistry or sulfur reaction validation; m3/h normal-state definition unresolved.')
source('S09','Simulation of Ladle Refining Reactions in Si–Mn-Killed Steel',2024,'10.1002/srin.202300330','https://doi.org/10.1002/srin.202300330','prior_fulltext_review','Si-Mn steel coupled reaction model','industrial inputs partly from 2005',note='2024 model publication reuses historical industrial data. Do not count as new 2024 plant observations.')
source('S10','Collaborative Optimization of Ladle Furnace Operating Parameters Using Prediction Models and Case-Guided Genetic–Tabu Search',2026,'10.3390/pr14182994','https://www.mdpi.com/2227-9717/14/18/2994','publisher_index','SPHC LF optimization','training 2023; evaluation January 2024',note='Plant specification not national grade limits; medians of nonzero additions are not one common heat.')
source('S11','ISIJ 2020 SMCC scheduling study (bibliographic title pending verification)',2020,'10.2355/isijinternational.ISIJINT-2019-423','https://www.jstage.jst.go.jp/article/isijinternational/60/6/60_ISIJINT-2019-423/_pdf/-char/en','publisher_pdf_index','Steelmaking-continuous-casting process duration statistics',note='Exact title/authors pending; numeric evidence Table 3 accessible.')
source('S12','Refining effect of IF steel produced by RH forced and natural decarburization process',2021,'10.13374/j.issn2095-9389.2020.10.10.002','https://cje.ustb.edu.cn/cn/article/doi/10.13374/j.issn2095-9389.2020.10.10.002','primary_abstract','Pangang Xichang IF BOF-LF-RH-CC plant study',note='LF used for heat deficit; RH oxygen supplied for forced decarburization; not a universal prohibition on LF before RH.')
source('S13','Decarburization Kinetics in RH Vacuum Refining Based on Flue Gas Analysis',2026,'10.2355/isijinternational.ISIJINT-2025-420','https://www.jstage.jst.go.jp/article/isijinternational/66/10/66_ISIJINT-2025-420/_html/-char/ja','full_text_partial_review','Online RH offgas carbon reconstruction',note='Introductory kinetic ranges cited from earlier work, not this paper fresh measurements.')
source('S14','Circulation flow rate and decarburization in the RH degasser under low atmospheric pressure',2018,'10.1016/j.vacuum.2018.04.007','https://www.sciencedirect.com/science/article/abs/pii/S0042207X18304238','primary_abstract','RH altitude, immersion and circulation CFD',note='Search page contained inconsistent related-volume metadata; publication year needs Crossref confirmation; treat year 2018 as provisional.')
source('S15','Aligning Real-Time Recurrence Computational Fluid Dynamics Simulations with Plant Data for the Ruhrstahl–Heraeus Degassing Process of Steel',2026,'10.1002/srin.202500395','https://doi.org/10.1002/srin.202500395','publisher_index','RH recurrence CFD and plant alignment',note='Online/issue year conflict 2025/2026; preserve unresolved original publication date.')
source('S16','Process optimization of bottom-blown argon for 130t ladle furnace',2023,'10.1080/03019233.2023.2218247','https://journals.sagepub.com/doi/full/10.1080/03019233.2023.2218247','primary_abstract','130 t LF gas practice',note='L/min in accessible abstract; do not silently normalize to NL/min.')
source('S17','Effects of Slag Composition and Impurities of Alloys on the Inclusion Transformation during Industrial Ladle Furnace Refining',2021,'10.3390/met11050763','https://www.mdpi.com/2075-4701/11/5/763','primary_abstract','LF slag oxidation and inclusion transformation')
source('S18','Adaptive First Principles Model for the CAS-OB Process for Real-Time Applications',2021,'10.3390/met11101554','https://www.mdpi.com/2075-4701/11/10/1554','publisher_index','CAS-OB coupled chemistry/thermal and state estimation',note='Model structure evidence; large variable counts are not a public plant training dataset.')
source('S19','Temperature prediction by a hybrid model for 150 t LF (exact title pending)',2022,'10.2355/isijinternational.ISIJINT-2021-251','https://www.jstage.jst.go.jp/article/isijinternational/62/3/62_ISIJINT-2021-251/_pdf','publisher_pdf_index','LF heat balance and hybrid temperature prediction')
source('S20','Flow Control to a T-shaped Five-strand Tundish (full title pending)',2023,'10.2355/isijinternational.ISIJINT-2023-008','https://www.jstage.jst.go.jp/article/isijinternational/advpub/0/advpub_ISIJINT-2023-008/_pdf','publisher_pdf_index','Tundish start-up and sequence superheat',note='Issue/online date precision pending. Grade-specific liquidus and casting speed.')
source('S21','Application of Graphite Electrode Plasma Heating Technology in Continuous Casting',2022,'10.3390/ma15072590','https://pmc.ncbi.nlm.nih.gov/articles/PMC9000347/','full_text_index','Tundish heating and thermal compensation',note='Statistics/illustrative distributions in paper are not universal process targets.')
source('S22','Numerical Simulation of Desulfurization Behavior in Ladle with Bottom Powder Injection',2018,'10.2355/isijinternational.ISIJINT-2018-406','https://www.jstage.jst.go.jp/article/isijinternational/58/11/58_ISIJINT-2018-406/_html/-char/ja','primary_fulltext_index','80 t ladle four-interface CFD-SRM')
source('S23','Mathematical modelling and plant trial on slagging regime in a ladle furnace for high-efficiency desulphurization',2021,'10.1080/03019233.2021.1935143','https://www.tandfonline.com/doi/abs/10.1080/03019233.2021.1935143','primary_abstract','LF slag making industrial trial')
source('S24','Exploration and innovation practice of nitrogen control technology in short process high quality steel production of electric furnace',2024,'10.13228/j.boyuan.issn0449-749x.20240305','https://www.chinamet.cn/gt/article/doi/10.13228/j.boyuan.issn0449-749x.20240305','metadata_only','EAF low nitrogen; Fujian Dingsheng coauthor',note='No quantitative process observations extracted; full text access timeout.')
source('S25','Green Power of Shougang, a New Chapter of Development',2025,None,'https://www.shougang.com.cn/en/p1/ShougangNews/20250110/122.html','official_plant_release','Shougang 2024 low-carbon steelmaking trial','2024',note='Plant announcement; scrap ratio/cast sequence facts, no kinetics calibration dataset.')
source('S26','Secondary metallurgy equipment',None,None,'https://www.sms-group.com/en-us/plants/secondary-metallurgy','manufacturer','LF RH VD VOD equipment capability',note='Undated capability reference; excluded from ten-year numeric corpus.')
source('S27','Special Metallurgy VIM ESR VAR',None,None,'https://www.danieli.com/en/products/processes-technologies/product-lines/special-metallurgy_26_208.htm','manufacturer','Special metallurgy extensions',note='Not core mass-produced carbon steel recipes; undated.')
source('S28','Steel desulfurization on RH degasser: physical and mathematical modeling',2021,None,'https://www.scielo.br/j/remi/a/wJ9TRHXvpWNWSdRhnRpjnSd/?format=html&lang=en','primary_abstract','RH desulfurization-specific circulation tradeoff')
source('S29','Synergistic Enhancement on Flow Behavior of Molten Steel in Different-Flowrate and Asymmetric Layout Bottom Blowing Ladle',2026,'10.2355/isijinternational.ISIJINT-2026-028','https://www.jstage.jst.go.jp/article/isijinternational/66/9/66_ISIJINT-2026-028/_html/-char/en','primary_abstract','120 t asymmetric dual plug CFD optimization')
source('S30','Efficient inclusion modification by calcium: ISIJ 63(2)303-312 (exact title pending)',2023,'10.2355/isijinternational.ISIJINT-2022-274','https://www.jstage.jst.go.jp/article/isijinternational/63/2/63_ISIJINT-2022-274/_pdf','publisher_pdf_index','Ca-Al-O-S inclusion modification window')
source('S31','Prediction of liquid circulation flow rate in RH degasser: improvement of decarburization at low atmospheric pressure',2024,'10.1007/s42243-023-01166-2','https://www.chinamet.cn/gtyjxbywb/en/article/doi/10.1007/s42243-023-01166-2?viewType=citedby-info','primary_abstract_and_pdf_header','RH population balance, circulation and industrial decarburization improvement',note='Published online 2024-04-15. Industrial success percentages are aggregates, not individual heat records.')
source('S32','Revealing the Relationship Between Macrostructures and Inclusions Across the Thickness Direction of Q235B Slabs',2024,'10.3390/cryst14121010','https://www.mdpi.com/2073-4352/14/12/1010','publisher_index','Ningbo Iron and Steel Q235B slab inclusion/solidification study',note='Metadata and liquidus equation indexed; full composition/processing table not yet verified. No invented plant recipe.')
source('S33','钢包精炼炉精炼渣系组分优化调控与应用',2025,'10.19864/j.cnki.jxye.2025.01.002','https://jxyj.publish.founderss.cn/academic?activeName=188350&bannerId=0&columnId=1746586796097&lang=zh&type=journal&year=2025','primary_abstract','HRB400 LF slag optimization',note='Abstract time/energy improvement figures and oxygen exponent appear anomalous; quarantined pending original PDF. Slag targets not terminal universal desulfurization slag.')
source('S34','Effects of Different RH Degasser Nozzle Layouts on the Circulating Flow Rate',2022,'10.3390/ma15238476','https://doi.org/10.3390/ma15238476','primary_abstract','RH water model nozzle layout and measured circulation',note='No numerical correlation copied before full tables verified.')
source('S35','LF精炼钢液温度预测模型（马钢120t研究，准确题名待核）',2024,None,'https://www.hbisco.com/uploads/2025-03-17/53d22a5d-c2f5-4852-92af-4136b9a773231742176969925.pdf','official_company_hosted_journal_pdf_index','Maanshan 120 t LF heat balance','not_reported','52-page journal issue hosted by HBIS; publication 2024-04, upload2025-03. Full article identification pending.')
source('S36','Two-way coupling calculation for multiphase flow and decarburization during RH refining',2019,'10.1016/j.vacuum.2019.06.018','https://doi.org/10.1016/j.vacuum.2019.06.018','citation_metadata_only','RH CO-Ar coupled bubbles and carbon reaction',note='Discovery lead only; no quantitative observations and no implemented correlation attributed to this paper.')

# Metadata corrections after targeted verification, retaining issue year separately.
for s in sources:
    if s['source_id']=='S11':s.update(title='Scheduling Model for the Practical Steelmaking-continuous Casting Production and Heuristic Algorithm Based on the Optimization of Furnace-caster Matching Mode',publication_date='2020-02-28',date_precision='day',note='First online 2020-02-28; issue2020-06-15. Numeric Table3 verified; authors not yet structured.')
    if s['source_id']=='S19':s.update(title='A Hybrid Modeling Method Based on Expert Control and Deep Neural Network for Temperature Prediction of Molten Steel in LF',publication_date='2022-01-08',date_precision='day')
    if s['source_id']=='S20':s.update(title='Flow Control to a T-shaped Five-strand Tundish for Its Overall Enhanced Metallurgical Effects with an Approachable Identical Products Quality',publication_date='2023-05-25',date_precision='day',note='First online2023-05-25; issue63(8)1351-1359; casting targets grade-specific.')
    if s['source_id']=='S30':s.update(title='Effect of Molten Steel Composition on Inclusion Modification by Calcium Treatment in Al-Killed Tinplate Steel',publication_date='2022-11-04',date_precision='day',note='First online2022-11-04; issue2023-02-15. Publication_year retains issue year.')
    if s['source_id']=='S15':s.update(publication_date='2025',date_precision='year',note='First-publication year2025 verified from author-institution original PDF; issue2026. Source https://www.k1-met.com/fileadmin/user_upload/Publications/Journal_articles_open_access/Zhang_et_al__2025__Aligning_real-time_rCFD_with_plant_data_RH_StResInt_online_article_paper_202500395.pdf')
    if s['source_id']=='S14':s.update(publication_date='2018',date_precision='year',note='Primary page copyright2018 and DOI verified. Related volume185(2021) at page end is a cited/citing item, not this article. Exact publication day not yet resolved.')
    if s['source_id']=='S04':s.update(publication_date='2023-12-06',date_precision='day')
    if s['source_id']=='S31':s.update(publication_date='2024-04-15',date_precision='day')
    if s['source_id']=='S32':s.update(publication_date='2024-11-21',date_precision='day')
    if s['source_id']=='S25':s.update(publication_date='2025-01-10',date_precision='day')

# Industrial gas practice: each plant is a separate case, not one synthesized ladle.
for cid,mass,d,h,rows in [('G44',44,2.010,1.814,[('rinsing',5,8),('arcing',20,25)]),('G185',185,3.580,2.625,[('rinsing',20,20),('arcing',80,80),('desulfurization',200,200)])]:
    case(cid,'S01','LF','unspecified','industrial_practice_report',{'gas_reference':'Nm3; definition per source','plug_count':'not_resolved'})
    obs(cid,'steel_mass',mass,'t','Table 1a');obs(cid,'diameter',d,'m','Table 1a');obs(cid,'bath_depth',h,'m','Table 1a')
    for stage,low,high in rows: obs(cid,'argon_flow_'+stage,low if low==high else None,'Nm3/h','Table 1a',lo=low,hi=high)
case('LES44','S02','LF','unspecified','numerical_model',{'interfaces':['flat','eye_edge','entrained_drops'],'gas_STP':True})
for p,v,u in [('ladle_radius',1,'m'),('bath_depth',2,'m'),('slag_thickness',0.1,'m'),('steel_density',7000,'kg/m3'),('slag_density',2800,'kg/m3'),('steel_temperature',1873,'K'),('sulfur_diffusivity',4.8e-9,'m2/s')]: obs('LES44',p,v,u,'Table 1 / section 2.5','A','model_input')
obs('LES44','specific_gas_flow',None,'NL/(min*t)','section 2.2','A','parameter_scan',1,4,note='Discrete 1,2,4; not continuous validated interval.')
case('CFDS2022','S03','LF','low_carbon','CFD_and_water_model',{'validation':'PIV flow; chemical endpoint transferability not established'})
for p,v in [('O_wt_pct',0.00022),('S_wt_pct',0.0165),('Al_wt_pct',0.0458),('C_wt_pct',0.0388),('Mn_wt_pct',0.1736),('Si_wt_pct',0.0073),('slag_CaO',62.82),('slag_Al2O3',26.6),('slag_SiO2',3.69),('slag_MgO',5.4),('slag_MnO',1.49)]:obs('CFDS2022',p,v,'wt%','Table 2','A','model_input')
case('W210','S04','LF','physical_model','water_model',{'prototype_t':210,'scale':0.1,'tracer':'thymol','not_steel_sulfur':True})
for p,v,u in [('prototype_bottom_diameter',3.513,'m'),('prototype_top_diameter',3.9,'m'),('prototype_total_height',5,'m'),('prototype_bath_depth',2.81,'m'),('prototype_slag_thickness',0.08,'m'),('prototype_plug_diameter',0.13,'m'),('water_height',0.281,'m'),('oil_thickness',0.008,'m'),('tracer_initial',100,'ppm'),('partition_mass_concentration',23,'1'),('partition_mass_fraction',35,'1')]:obs('W210',p,v,u,'Table 1; section 3.1')

# Bounded matched extraction from Table 7 and 9, retain '-' as unreported, not zero.
s355=[(1,107,30.3,283,99.9,74,None,None),(3,29,9,310,99.9,74,300,172),(4,39,16.9,433,86.1,100,454,52),(6,23,13.3,578,98.6,188,None,50),(11,39,15,385,105.5,232,200,252),(16,34,15.1,444,99.4,None,254,274),(19,25,13.8,552,107.6,426,None,52),(21,23,14.4,626,109.7,190,80,152)]
for n,t,qv,q,m,fm,fsm,fs in s355:
    cid=f'S355H{n:02d}';case(cid,'S05','LF','S355','industrial_heat',{'paper_heat_number':n,'gas_reference':'unspecified','exceptional_hold':t>=90,'high_flow_leakage_possible':q>=600})
    for p,v,u,loc in [('duration',t,'min','Table 7'),('argon_volume',qv,'m3_unspecified','Table 7'),('argon_mean_flow',q,'dm3/min_unspecified','Table 7'),('steel_mass',m,'t','Table 7'),('FeMn_addition',fm,'kg','Table 9'),('FeSiMn_addition',fsm,'kg','Table 9'),('FeSi_addition',fs,'kg','Table 9')]:
        if v is not None: obs(cid,p,v,u,f'{loc}, heat {n}')
    if n==16:
        parents=[o['observation_id'] for o in observations if o['case_id']==cid and o['parameter'] in ('argon_volume','steel_mass')]
        derive(cid,'specific_argon_volume',qv/m,'m3_unspecified/t',parents,'argon_volume/steel_mass','Not Nm3/t; gas standard state not reported.')
case('S355CFD','S05','LF','S355','numerical_model',{'slag_omitted':True,'mixing_criterion':'95%','one_way_DPM':True})
for p,v,u in [('cp',680,'J/(kg*K)'),('dynamic_viscosity',0.0062,'Pa*s'),('bubble_diameter',0.015,'m'),('flow_case_1',300,'dm3/min_unspecified'),('flow_case_2',500,'dm3/min_unspecified'),('mixing_case_1_at_P1',108,'s'),('mixing_case_2_at_P1',107,'s'),('mixing_case_2_max',128,'s')]:obs('S355CFD',p,v,u,'Table 6; section 3 / Table 13','A','CFD_or_adopted_input')

case('Q355Ti','S06','BOF-LF-CC','Q355B','industrial_optimization',{'plant':'Baowu Echeng','standard_recipe':False,'routes':'Ti addition delayed after deoxidation'})
for p,v,u,loc,role in [('lime_before',5.3,'kg/t','section 4.3.3','baseline'),('lime_after',6.6,'kg/t','section 4.3.3','intervention'),('basicity_target_min',4,'CaO/SiO2','section 4.3.3','plant_target'),('Ti_addition_oxygen_max',5,'ppm_oxygen_activity','section 4.3.2 / conclusions','plant_target'),('S_target_max',0.010,'wt%','section 4.4','plant_target'),('Mn_over_S_target_min',50,'1','section 4.4','plant_target'),('S_mean_before',0.021,'wt%','Table 2','measured_mean'),('S_mean_after',0.009,'wt%','Table 2','measured_mean')]:obs('Q355Ti',p,v,u,loc,role=role)
for p,low,high in [('C',0.16,0.20),('Si',0.25,0.35),('Mn_Ti_route',0.70,0.90),('Ti',0.030,0.050),('Al',0.015,0.040)]:obs('Q355Ti','recipe_'+p,None,'wt%','Table 1, new process',role='plant_recipe',lo=low,hi=high)

case('VD105','S07','VD','unspecified','numerical_baseline',{'gas_reference':'NL/min','two_plugs_total':True,'pressure':'absolute'})
o1=obs('VD105','steel_mass',105,'t','section 2 / Fig 2','A','model_input');o2=obs('VD105','argon_flow',260,'NL/min','section 2 / Fig 2','A','model_input');o3=obs('VD105','hold_duration',18,'min','section 2 / Fig 2','A','model_input');obs('VD105','pressure',66,'Pa_abs','section 2 / Fig 2','A','model_input')
derive('VD105','argon_volume',260*18/1000,'Nm3',[o2,o3],'NL/min * min / 1000','Only stated holding segment; excludes pumping and soft stirring.')
derive('VD105','specific_argon_volume',260*18/1000/105,'Nm3/t',[o1,o2,o3],'Q*t/(1000*M_t)')
case('RH120P','S08','RH-powder','unspecified','CFD_and_water_model',{'mass_t':120,'chemistry_not_reported':True,'gas_reference':'unspecified'})
for p,v,u in [('steel_mass',120,'t'),('powder_duration',480,'s'),('powder_density',3350,'kg/m3'),('carrier_flow',36,'m3/h_unspecified'),('vacuum_pressure',133,'Pa_abs')]:obs('RH120P',p,v,u,'Table 3; sections 3.3-3.4','A','model_input')
for p,low,high,u,note in [('powder_rate',0.5,1.5,'kg/s','Discrete 0.5,0.75,1,1.25,1.5'),('lift_gas',60,150,'m3/h_unspecified','Discrete 60,90,110,120,150'),('particle_size',30,500,'um','Discrete 30,80,150,220,300,500')]:obs('RH120P',p,None,u,'Table 3','A','parameter_scan',low,high,note)
case('SiMn120','S09','LF','SiMn_killed','historical_industrial_model_inputs',{'case':'C1','steel_t':120,'single_plug':True,'original_industrial_year':2005})
for p,v,u in [('steel_mass',120,'t'),('FeSi',120,'kg'),('SiMn',2126,'kg'),('lime',1281,'kg'),('CaF2',340,'kg'),('MgO',54,'kg'),('FeV',45,'kg'),('CaSi',9,'kg'),('argon_flow',11.24,'Nm3/h')]:obs('SiMn120',p,v,u,'Tables 4 and 7; section 3',tag='A',role='historical_input')
case('SPHC','S10','LF','SPHC','plant_specification',{'data_vintage':'2023/2024','not_standard':True})
for p,low,high,u in [('C',0.03,0.06,'wt%'),('Mn',0.15,0.40,'wt%'),('Als',0.023,0.040,'wt%'),('Ca',15,25,'ppm'),('temperature',1590,1600,'degC')]:obs('SPHC',p,None,u,'section 4.1','R','plant_target',low,high)
for p,v in [('S',0.015),('Si',0.03),('P',0.022)]:obs('SPHC',p,v,'wt%','section 4.1',role='plant_upper_limit')

for cid,process,low,high,mean,n in [('LFheat','LF-heating',23,37,31,2701),('LFsoft','soft-stirring',8,16,12,2701),('RHtime','RH',11,38,31,627),('CC1','CC',41,55,45,1619),('CC2','CC',27,44,35,1407),('CC3','CC',51,70,55,1412),('CC4','CC',25,58,35,1127)]:
    case(cid,'S11',process,'mixed','industrial_aggregate',{'sample_size':n,'not_individual_heats':True})
    obs(cid,'duration',None,'min','Table 3',role='observed_range',lo=low,hi=high);obs(cid,'duration_mean',mean,'min','Table 3',role='observed_mean')
case('IFforced','S12','BOF-LF-RH-CC','IF','industrial_comparison',{'plant':'Pangang Xichang','LF_role':'heat compensation','final_deoxidation':'after decarburization'})
obs('IFforced','slag_TFe_decrease',1.3,'percentage_points','abstract',role='difference_vs_natural_decarburization',note='Difference in mass fraction, not relative 1.3 percent.')
for p,v in [('Al2O3_mean_size',4.5),('Al2O3_TiOx_mean_size',4.4),('other_inclusion_mean_size',6.5)]:obs('IFforced',p,v,'um','abstract',role='observed_mean')
case('RHoffgas','S13','RH','IF_ULC','industrial_method',{'stage_varying_kinetics':True,'historical_ranges_only':True})
case('RH210','S13','RH','low_carbon_ULC','industrial_equipment_conditions',{'route':'KR-BOF-RH-CC','gas_lift_reference':'L/min unspecified','snorkel_dimension':'650*980 mm as printed; do not interpret both as diameters'})
for p,v,u in [('ladle_capacity',210,'t'),('ultimate_pressure',100,'Pa_abs'),('oxygen_flow',1200,'Nm3/h'),('lift_gas',3000,'L/min_unspecified'),('rapid_pump_duration',1.5,'min'),('pressure_platform_duration',3.6,'min'),('deep_pump_duration',1.5,'min')]:obs('RH210',p,v,u,'Table 1 / section 2.1')
for p,low,high,u in [('snorkel_immersion',600,750,'mm'),('initial_C',195,592,'ppm'),('decarburization_duration',10,20,'min'),('pressure_platform',500,700,'Pa_abs')]:obs('RH210',p,None,u,'Table 1 / section 2.1',lo=low,hi=high)
obs('RH210','ordinary_target_C_max',30,'ppm','section 2.1',role='plant_target');obs('RH210','ULC_target_C_max',10,'ppm','section 2.1',role='plant_target')
obs('RHoffgas','oxygen_blowing_kC',None,'1/min','Introduction, cited prior study','F','historical_range',0.1,0.9,note='Do not treat as this study fitted coefficient or deploy without calibration.')
obs('RHoffgas','natural_decarburization_kC',None,'1/min','Introduction, cited prior study','F','historical_range',0.06,0.09)
case('RHaltitude','S14','RH','ULC','numerical_comparison',{'date_pending':True,'conditions':'low atmospheric pressure; no general interpolation authorized'})
for p,v,u in [('immersion_baseline',0.5,'m'),('immersion_modified',0.75,'m'),('circulation_baseline',90.5,'t/min'),('circulation_modified',120.9,'t/min')]:obs('RHaltitude',p,v,u,'abstract',tag='A',role='numerical_result')
case('RHrec','S15','RH','unspecified','CFD_plant_alignment',{'not_universal_limits':True})
obs('RHrec','lift_gas_low',78,'Nm3/h','abstract / conclusions','A','CFD_input');obs('RHrec','lift_gas_high',124,'Nm3/h','abstract / conclusions','A','CFD_input')
case('LF130','S16','LF','unspecified','optimized_practice',{'steel_t':130,'standard_state_not_explicit':True})
obs('LF130','alloying_heating_flow',None,'L/min_unspecified','abstract','F','recommended_range',240,300);obs('LF130','soft_flow',None,'L/min_unspecified','abstract','F','recommended_range',60,120)
case('SlagOx','S17','LF','Al_killed','industrial_comparison',{'not_general_target':True})
obs('SlagOx','initial_FeO_plus_MnO_approx',10,'wt%','abstract',role='reported_approximate')
case('CASmodel','S18','CAS-OB','unspecified','model_structure',{'not_public_training_set':True})
obs('CASmodel','number_ODE',61,'count','section 2.4.4','A','model_structure');obs('CASmodel','input_variables',50,'count','section 2.4.4','A','model_structure')
case('LF150T','S19','LF','mixed','model_training_summary',{'steel_t':150,'raw_heats_not_public':True})
obs('LF150T','training_count',1500,'count','section 3.1',role='study_sample_count');obs('LF150T','test_count',500,'count','section 3.1',role='study_sample_count')
case('TD5','S20','tundish-CC','unspecified','reported_casting_conditions',{'first_heat_different':True})
for p,low,high,u in [('liquidus',1503,1505,'degC'),('first_superheat',30,55,'K'),('sequence_superheat',15,30,'K'),('sequence_temperature',1515,1535,'degC')]:obs('TD5',p,None,u,'Table 8',lo=low,hi=high)
case('TDheat','S21','tundish','mixed','temperature_control_study',{'context_specific':True})
obs('TDheat','upstream_temperature_reduction',None,'K','abstract / conclusions',role='reported_benefit',lo=10,hi=15)
case('Powder80','S22','LF-powder','unspecified','CFD_SRM',{'interfaces':['slag-metal','air-metal','powder-metal','bubble-metal']})
obs('Powder80','steel_mass',80,'t','section 2.1','A','model_geometry')
case('SlagTrial','S23','LF','unspecified','industrial_trial',{'success_criterion':'source desulfurization requirement; exact threshold not extracted'})
obs('SlagTrial','successful_heats',45,'count','abstract',role='trial_count');obs('SlagTrial','tested_heats',48,'count','abstract',role='trial_count')
case('SGIF','S25','BOF-CC','IF','official_plant_announcement',{'plant':'Shougang Jingtang','year':2024,'kinetics_calibration':False})
obs('SGIF','scrap_ratio',50,'percent','2025-01-10 official article',role='trial_condition');obs('SGIF','consecutive_cast_heats',7,'count','2025-01-10 official article',role='trial_result')
case('RHdesS','S28','RH','unspecified','kinetic_model',{'specific_desulfurization_stage':True})
obs('RHdesS','best_gas_flow',90,'Nm3/h','abstract','F','model_optimum');obs('RHdesS','desulfurization_degree',31.44,'percent','abstract','A','model_result')
case('Dual120','S29','LF','unspecified','numerical_comparison',{'steel_t':120,'flow_reference':'L/min unspecified','plug_layout':'0.67r-0.7r,60deg','baseline':'0.67r-0.67r, 1:1'})
obs('Dual120','total_flow',400,'L/min_unspecified','abstract','A','model_input');obs('Dual120','flow_ratio',2,'1','abstract','A','model_input');obs('Dual120','kinetic_energy_increase',25.93,'percent','abstract','A','relative_change');obs('Dual120','dead_zone_reduction',30.42,'percent','abstract','A','relative_change')
case('RH2024deep','S31','RH','ULC','industrial_aggregate_and_CFD',{'atmosphere_kPa':[101,84],'comparison':'before_after','individual_heats_unavailable':True})
for p,v,u,role in [('immersion_before',0.5,'m','model_condition'),('immersion_after',0.7,'m','model_condition'),('C_target_max',0.002,'wt%','plant_target'),('success_before',22.0,'percent','industrial_aggregate'),('success_after',96.4,'percent','industrial_aggregate')]:obs('RH2024deep',p,v,u,'abstract',role=role)
case('HRBslag','S33','LF','HRB400','industrial_optimization',{'slag_stage':'entry_target','terminal_slag_not_specified':True})
for p,v,u in [('entry_basicity_target',1.5,'CaO/SiO2'),('slag_Al2O3_target',10,'wt%'),('slag_MgO_target',8,'wt%'),('slag_MnO_target',6,'wt%'),('slag_CaF2_target',3,'wt%'),('slag_Fe2O3_target',2,'wt%')]:obs('HRBslag',p,v,u,'abstract','F','entry_slag_target')
for p,v,u in [('time_saving_raw',0.024,'s'),('electricity_saving_raw',0.105,'kWh'),('oxygen_raw',3e-7,'fraction_or_basis_unresolved')]:
    obs('HRBslag',p,v,u,'abstract as indexed','U','quarantined_reported_value',note='Potential unit/exponent error. Must not use for prediction or industrial benefit claims.')
    observations[-1]['review_status']='quarantined_pending_primary_pdf'

def build():
    from registry import MODELS, REACTIONS, EQUIPMENT, GRADES, ROUTES, GAPS
    data=ROOT/'data';data.mkdir(exist_ok=True)
    assets=[]
    for sid,path in [('S06',ROOT.parent/'refining_literature_2021_2026/sources/q355_2022.pdf'),('S08',ROOT.parent/'refining_literature_2021_2026/sources/rh_powder_2023.pdf')]:
        if path.exists():assets.append(dict(source_id=sid,local_path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),kind='existing_primary_pdf'))
    tables={'sources':sources,'cases':cases,'observations':observations,'derivations':derivations,
        'models':MODELS,'reactions':REACTIONS,'equipment':EQUIPMENT,'grade_families':GRADES,
        'routes':ROUTES,'data_gaps':GAPS,'source_assets':assets}
    db=data/'refining.sqlite'
    if db.exists(): db.unlink() # Only this generated DB in this dedicated folder; sources preserved.
    con=sqlite3.connect(db);con.execute('PRAGMA foreign_keys=ON')
    con.executescript('''
    CREATE TABLE sources(source_id TEXT PRIMARY KEY,title TEXT NOT NULL,publication_year INTEGER,doi TEXT UNIQUE,url TEXT NOT NULL,verified_on TEXT,access_level TEXT,scope TEXT,original_data_vintage TEXT,note TEXT,date_precision TEXT,publication_date TEXT,numeric_corpus INTEGER);
    CREATE TABLE cases(case_id TEXT PRIMARY KEY,source_id TEXT NOT NULL REFERENCES sources,process TEXT,grade TEXT,study_kind TEXT,context_json TEXT NOT NULL);
    CREATE TABLE observations(observation_id TEXT PRIMARY KEY,case_id TEXT NOT NULL REFERENCES cases,source_id TEXT NOT NULL REFERENCES sources,parameter TEXT NOT NULL,value REAL,lower_value REAL,upper_value REAL,unit TEXT NOT NULL,evidence_tag TEXT CHECK(evidence_tag IN ('R','D','A','F','U')),quantity_role TEXT,locator TEXT NOT NULL,extraction_method TEXT,note TEXT,review_status TEXT,uncertainty REAL,CHECK(value IS NOT NULL OR lower_value IS NOT NULL OR upper_value IS NOT NULL),CHECK(lower_value IS NULL OR upper_value IS NULL OR lower_value<=upper_value));
    CREATE TABLE derivations(derived_observation_id TEXT PRIMARY KEY REFERENCES observations,parent_ids_json TEXT,formula TEXT);
    CREATE TABLE models(model_id TEXT PRIMARY KEY,name TEXT,equation TEXT,inputs_json TEXT,output_units TEXT,source_ids_json TEXT,derivation TEXT,domain TEXT,status TEXT,implementation TEXT);
    CREATE TABLE reactions(reaction_id TEXT PRIMARY KEY,name TEXT,equation TEXT,processes TEXT,source_ids_json TEXT,note TEXT);
    CREATE TABLE equipment(equipment_id TEXT PRIMARY KEY,name TEXT,scope TEXT,functions TEXT,temperature_rule TEXT,time_rule TEXT,source_ids_json TEXT,status TEXT);
    CREATE TABLE grade_families(grade_id TEXT PRIMARY KEY,name TEXT,examples TEXT,quality_drivers TEXT,coverage_status TEXT,note TEXT);
    CREATE TABLE routes(route_id TEXT PRIMARY KEY,grade_id TEXT REFERENCES grade_families,steps_json TEXT,selection_rule TEXT,source_ids_json TEXT,status TEXT);
    CREATE TABLE data_gaps(gap_id TEXT PRIMARY KEY,topic TEXT,severity TEXT,missing_data TEXT,impact TEXT,next_action TEXT);
    CREATE TABLE source_assets(source_id TEXT REFERENCES sources,local_path TEXT,sha256 TEXT,kind TEXT);
    CREATE TABLE heat_imports(plant_id TEXT,heat_id TEXT,equipment_id TEXT,event_time TEXT,event_type TEXT,value REAL,unit TEXT,parameter TEXT,quality_flag TEXT,source_file TEXT,PRIMARY KEY(plant_id,heat_id,event_time,event_type,parameter));
    CREATE TABLE calibrations(calibration_id TEXT PRIMARY KEY,model_id TEXT REFERENCES models,plant_id TEXT,equipment_id TEXT,parameter_json TEXT,training_heat_ids_json TEXT,test_heat_ids_json TEXT,metrics_json TEXT,status TEXT);
    CREATE TABLE predictions(run_id TEXT PRIMARY KEY,scenario_type TEXT,input_json TEXT,result_json TEXT,model_ids_json TEXT,source_ids_json TEXT,calibration_id TEXT REFERENCES calibrations,created_on TEXT);
    CREATE VIEW evidence_chain AS SELECT o.*,c.process,c.grade,c.study_kind,c.context_json,s.title,s.publication_year,s.original_data_vintage,s.url,s.access_level FROM observations o JOIN cases c USING(case_id) JOIN sources s ON o.source_id=s.source_id;
    CREATE VIEW contemporary_evidence AS SELECT * FROM evidence_chain WHERE publication_year BETWEEN 2017 AND 2026 AND quantity_role NOT IN ('historical_input','historical_range') AND evidence_tag<>'U';
    CREATE VIEW usable_reference_evidence AS SELECT * FROM evidence_chain WHERE evidence_tag<>'U' AND quantity_role NOT IN ('historical_range','historical_input') AND review_status='checked_with_accessible_text';
    CREATE INDEX observations_param ON observations(parameter);
    CREATE INDEX cases_process ON cases(process);
    ''')
    for name,rows in tables.items():
        if not rows:continue
        columns=list(rows[0]);con.executemany(f'INSERT INTO {name} ({",".join(columns)}) VALUES ({",".join("?" for _ in columns)})',[[r.get(k) for k in columns] for r in rows])
        with (data/f'{name}.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,columns);w.writeheader();w.writerows(rows)
    con.commit();assert not con.execute('PRAGMA foreign_key_check').fetchall()
    (data/'seed.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2),encoding='utf-8')
    con.close();print(json.dumps({k:len(v) for k,v in tables.items()},ensure_ascii=False))

if __name__=='__main__':build()
